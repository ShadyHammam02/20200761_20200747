package project;

public class Quarter extends Landline_Service{
	
	public void Quarter(){
		System.out.print("Paying quarter bill. ");
	}
}
