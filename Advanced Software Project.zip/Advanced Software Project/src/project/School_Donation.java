package project;

public class School_Donation extends Donation_Service{
	
	public School_Donation(){
		System.out.print("Thanks for donating to school service. ");
	}

}
