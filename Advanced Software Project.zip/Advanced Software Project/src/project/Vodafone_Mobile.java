package project;

public class Vodafone_Mobile extends Mobile_Service{
	
	public Vodafone_Mobile(){
		System.out.print("Vodafone mobile service ");
	}

}
