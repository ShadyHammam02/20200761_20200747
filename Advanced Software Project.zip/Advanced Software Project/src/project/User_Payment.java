package project;

public abstract class User_Payment {
	
	public abstract void pay(int cost);
}
