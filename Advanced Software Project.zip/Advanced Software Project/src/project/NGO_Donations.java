package project;

public class NGO_Donations extends Donation_Service{
	
	
	public NGO_Donations(){
		System.out.print("Thanks for donating to NGO service. ");
	}

}
