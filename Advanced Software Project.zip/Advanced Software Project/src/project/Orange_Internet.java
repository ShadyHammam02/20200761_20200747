package project;

public class Orange_Internet extends Internet_Service{
	
	public Orange_Internet(){
		System.out.print("Orange internet service ");
	}
	
}
