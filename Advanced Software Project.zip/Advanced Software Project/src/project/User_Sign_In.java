package project;

//import java.util.Scanner;

public class User_Sign_In extends User{

	public User_Sign_In(String email, String password) {
		super(email, password);
	}
	
	public void SignIn(String email,String password){
		
		System.out.println("Sign in success. ");
	}

}
