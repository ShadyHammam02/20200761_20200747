package project;

public class Cash_Payment extends User_Payment{

	public void pay(int cost) {
		System.out.print("Payment of " + cost + " is done using cash. ");
		
	}

}
