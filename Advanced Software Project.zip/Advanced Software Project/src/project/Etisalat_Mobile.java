package project;

public class Etisalat_Mobile extends Mobile_Service{
	
	public Etisalat_Mobile(){
		System.out.print("Etisalat mobile service ");
	}

}
