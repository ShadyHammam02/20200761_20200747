package project;

import java.util.ArrayList;


public class Admin_Refund_List {
	
	ArrayList<String> refundRequests = new ArrayList<String>();
	
	public void accept(){
		System.out.print("Reaquest accepted ");
	}
	
	public void Deny(){
		System.out.print("Reaquest denied ");
	}
	
}
