package project;

public class Monthly extends Landline_Service{

	public Monthly(){
		System.out.print("Paying monthly bill. ");
	}
}
