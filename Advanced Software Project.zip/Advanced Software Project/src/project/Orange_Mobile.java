package project;

public class Orange_Mobile extends Mobile_Service{
	
	public Orange_Mobile(){
		System.out.print("Orange mobile service ");
	}

}
