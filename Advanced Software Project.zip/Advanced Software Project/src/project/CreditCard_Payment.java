package project;

public class CreditCard_Payment extends User_Payment{

	public void pay(int cost) {
		System.out.print("Payment of " + cost + " is done using credit card. ");
	}

}
