package project;

public class Cancer_Donation extends Donation_Service{
	
	public Cancer_Donation(){
		System.out.print("Thanks for donating to cancer service. ");
	}

}
