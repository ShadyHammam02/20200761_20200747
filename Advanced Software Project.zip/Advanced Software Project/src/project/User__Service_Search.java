package project;

public class User__Service_Search {
	Services obj;
	
	public void Search(String service){
		obj.orderService(service);
	}
}
