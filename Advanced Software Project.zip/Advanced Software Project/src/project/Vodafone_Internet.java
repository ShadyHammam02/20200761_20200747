package project;

public class Vodafone_Internet extends Internet_Service{
	
	public Vodafone_Internet(){
		System.out.print("Vodafone internet service ");
	}

}
