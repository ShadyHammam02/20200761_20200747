package project;

public class We_Mobile extends Mobile_Service{
	
	public We_Mobile(){
		System.out.print("We mobile service ");
	}

}
