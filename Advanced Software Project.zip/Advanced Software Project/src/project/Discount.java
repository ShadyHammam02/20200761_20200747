package project;

public interface Discount {
	
	public boolean addDiscount();

}
