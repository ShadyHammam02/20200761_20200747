package project;

public class We_Internet extends Internet_Service{
	
	public We_Internet(){
		System.out.print("We internet service");
	}

}
