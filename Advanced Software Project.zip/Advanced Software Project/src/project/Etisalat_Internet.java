package project;

public class Etisalat_Internet extends Internet_Service{
	
	public Etisalat_Internet(){
		System.out.print("Etisalat internet service");
	}

}
